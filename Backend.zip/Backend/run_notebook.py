# run_notebook.py
# Usage: python run_notebook.py /absolute/path/to/notebook.ipynb
import sys, json, nbformat, io, traceback
from nbformat import read

def run_notebook(path):
    outputs = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            nb = nbformat.read(f, as_version=4)
    except Exception as e:
        return {"status": "error", "error": f"Failed to open notebook: {e}"}

    # We'll execute code cells in sequence in one shared namespace
    globs = {}
    for i, cell in enumerate(nb.cells):
        if cell.cell_type != 'code':
            continue
        src = ''.join(cell.get('source', []))
        # capture stdout
        stdout_buf = io.StringIO()
        try:
            old_stdout = sys.stdout
            sys.stdout = stdout_buf
            exec(src, globs)
            sys.stdout = old_stdout
            out_text = stdout_buf.getvalue()
            outputs.append({"cell_index": i, "status": "ok", "output": out_text})
        except Exception as e:
            sys.stdout = old_stdout
            tb = traceback.format_exc()
            outputs.append({"cell_index": i, "status": "error", "error": str(e), "traceback": tb})
            # Stop execution on first error (you can change to continue)
            return {"status": "error", "outputs": outputs}
    return {"status": "ok", "outputs": outputs}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"status":"error","error":"notebook path required"}))
        sys.exit(1)
    nbpath = sys.argv[1]
    result = run_notebook(nbpath)
    print(json.dumps(result))
