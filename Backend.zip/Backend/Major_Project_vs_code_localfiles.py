import re
import nltk

import nltk
nltk.download('punkt_tab')

import os, glob

print("Loading .txt lyric files from local 'lyrics' folder...")

lyrics_dir = os.path.join(os.getcwd(), "lyrics")  # folder next to this notebook

documents = []
filenames = []

for filepath in glob.glob(os.path.join(lyrics_dir, "*.txt")):
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        documents.append(f.read())
        filenames.append(os.path.basename(filepath))

print(f"Loaded {len(documents)} files from {lyrics_dir}")

HAPPY = set("""
happy joy joyful joyfulness love lovely sunshine sunny bright smile smiles party dance dancing celebrate celebration
good great amazing awesome best upbeat cherish hug hugs kisses shining shine victory together freedom fun phenomenal
bliss cheerful delight delighted laughter laugh grin grinning optimism optimistic
""".split())

SAD = set("""
sad sorrow pain lonely alone tears crying cry hurt hurting broken breakdown regret regrets mistake mistakes bitter
bittersweet darkness dark cold miss missing goodbye over apart worry worries burden heavy tired blue blues despair
heartbreak heartbroken grief grieving melancholy mourn mourning downcast
""".split())

ENERGETIC = set("""
energy energetic fire electric lightning speed rush power pulse beat beats bass jump move shake wild roar ignite pump
hype turbo bounce sprint adrenaline storm thunder rave mosh slam drive fast furious racing heat hustle tempo
""".split())

NOSTALGIC = set("""
nostalgic nostalgia memory memories remember remembering reminiscent reminisce yesterday yesterdays throwback rewind
olden golden vintage classic hometown homecoming home return again childhood teenage school college summer winter spring fall
decade back then backthen old days
""".split())

EMOTIONAL = set("""
tears tear heart hearts heartfelt feeling feelings emotion emotional fragile tender touch touching soulful deep ache aching
cry crying broken break breaking bleed bleeding longing yearning empathy comfort comforted
""".split())

SENTI_LEX = {
    "Happy": HAPPY,
    "Sad": SAD,
    "Energetic": ENERGETIC,
    "Nostalgic": NOSTALGIC,
    "Emotional": EMOTIONAL,
}

def normalize(text: str):
    return re.findall(r"[a-zA-Z]+(?:'[a-zA-Z]+)?", text.lower())


def mood_label(score: float) -> str:
    return "happy" if score >= 0 else "sad"

def detect_bollywood_hollywood(filename: str, text: str) -> str:
    name = filename.lower()
    if "bollywood" in name: return "bollywood"
    if "holly" in name or "hollywood" in name: return "hollywood"
    if re.search(r"[\u0900-\u097F]", text):  # check Hindi script
        return "bollywood"
    return "hollywood"

def sentiment_scores(text: str):
    words = normalize(text)
    n = max(1, len(words))
    scores = {}
    for label, lex in SENTI_LEX.items():
        count = sum(1 for w in words if w in lex)
        scores[label] = count / n
    return scores

def mood_label(scores: dict) -> str:
    best = max(scores, key=scores.get)
    if all(v == 0 for v in scores.values()):
        return "Emotional"
    return best

GENRE_KEYWORDS = {
    "jazz": set("""
        jazz swing blue blues improv improvisation solo solos sax saxophone trumpet horn bebop cool fusion groove
        syncopation scat quartet trio brushes upright
    """.split()),
    "rock": set("""
        rock guitar riff riffs drum drums amp amps band crowd scream grunge metal punk mosh solo solos distortion
        power chord stadium garage
    """.split()),
    "pop": set("""
        pop radio chorus catchy hook dancefloor chart bubblegum glitter mainstream hit hits single remix
    """.split()),
}

def detect_genre(filename: str, text: str) -> str:
    name = filename.lower()
    if "jazz" in name: return "jazz"
    if "rock" in name: return "rock"
    if "pop"  in name: return "pop"

    words = set(normalize(text))
    # count keyword hits per genre
    hits = {g: sum(1 for w in words if w in kw) for g, kw in GENRE_KEYWORDS.items()}
    # pick the genre with max hits; default to 'pop' if all zero
    best = max(hits, key=hits.get) if hits else "pop"
    if all(v == 0 for v in hits.values()):
        return "pop"
    return best


records = []
for fname, text in zip(filenames, documents):
    scores = sentiment_scores(text)
    label = mood_label(scores)
    records.append({
        "filename": fname,
        "text": text,
        "sentiment_score": scores[label],  # score for the chosen label
        "mood": label,                     # one of: Happy/Sad/Energetic/Nostalgic/Emotional
        "genre": detect_genre(fname, text) # one of: jazz/rock/pop
    })

df = pd.DataFrame(records)
print(df[["filename", "mood", "genre", "sentiment_score"]].head())

vectorizer = TfidfVectorizer(stop_words="english")
tfidf_matrix = vectorizer.fit_transform(df["text"].tolist())

def pick_lyrics(theme: str, mood: str, genre: str):
    # strict: match both mood + genre
    mask = (df["mood"].str.lower() == mood.lower()) & (df["genre"].str.lower() == genre.lower())
    candidates = df[mask]

    # fallback 1: match mood only
    if candidates.empty:
        candidates = df[df["mood"].str.lower() == mood.lower()]

    # fallback 2: all docs
    if candidates.empty:
        candidates = df

    user_vec = vectorizer.transform([theme])
    cand_indices = candidates.index.tolist()
    cand_matrix = tfidf_matrix[cand_indices]
    sims = cosine_similarity(user_vec, cand_matrix).flatten()
    best_idx_local = sims.argmax()
    best_row = candidates.iloc[best_idx_local]
    return best_row, float(sims[best_idx_local])

theme = "dance party celebration love"
mood = "Energetic"   # choose from: Happy, Sad, Energetic, Nostalgic, Emotional
genre = "Jazz"       # choose from: Jazz, Rock, Pop (case-insensitive)

row, sim = pick_lyrics(theme, mood, genre)
print("Chosen file:", row["filename"])
print("Mood:", row["mood"], "| Genre:", row["genre"], "| Score:", row["sentiment_score"])
print("Cosine similarity:", sim, "\n")
print("--- Full Lyrics ---\n")
print(row["text"])


