# Backend/model_logic.py
"""
Hybrid mood detection for lyrics:
- Trains a TF-IDF + Logistic Regression classifier on local .txt files
- Uses filename keywords to label each file (happy, sad, energetic, calm, emotional, nostalgic)
- If ML model is not available, falls back to keyword-based rules
- Functions used by Flask:
    - run_lyrics_pipeline()
    - detect_mood_for_text(text)
"""

import os
import glob
import re
from collections import Counter
# model_logic.py (top of file)
from simple_keyword_model import kw_detect_mood  # the high-precision keyword model


# ML imports
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import numpy as np

# ───────────────────────────────
# 1. Moods & keyword dictionaries
# ───────────────────────────────

MOOD_LABELS = ["happy", "sad", "energetic", "calm", "emotional", "nostalgic"]

SAD_WORDS = {
    "sad", "sadness", "cry", "crying", "cried", "tears", "tearful",
    "alone", "lonely", "isolation", "dark", "darkness",
    "pain", "painful", "hurt", "hurting", "wounded",
    "broken", "empty", "goodbye", "lost", "loss", "regret",
    "heartbreak", "heartbroken", "depressed", "depression", "sorrow",
    "mourning", "weep", "weeping", "upset", "miserable", "gloomy",
    "blue", "down", "aching", "hopeless"
}

HAPPY_WORDS = {
    "happy", "happiness", "joy", "joyful", "smile", "smiling",
    "cheer", "cheerful", "delight", "delighted", "bright",
    "sun", "sunshine", "positive", "glad",
    "laugh", "laughing", "love", "loving", "beloved",
    "bliss", "blissful", "grateful", "thankful",
    "paradise", "celebrate", "celebration",
    "excited", "exciting", "peace", "peaceful",
    "hope", "hopeful", "comfort", "comforting"
}

ENERGETIC_WORDS = {
    "energy", "energetic", "power", "powerful", "fast", "speed",
    "run", "running", "rush", "strong", "strength", "wild",
    "fire", "flame", "burn", "burning", "intense", "rising",
    "rise", "pump", "pumped", "action", "active",
    "unstoppable", "boom", "electric", "shock",
    "thunder", "storm", "loud", "move", "moving",
    "heartbeat", "drive", "force", "impact"
}

CALM_WORDS = {
    "calm", "calming", "peace", "peaceful", "breeze", "wind",
    "soft", "gentle", "slow", "relax", "relaxing", "rest", "restful",
    "quiet", "silence", "silent", "still", "stillness",
    "soothing", "comfort", "comforting",
    "ocean", "sea", "wave", "waves",
    "moonlight", "serene", "serenity",
    "balance", "stable", "cozy", "warm",
    "whisper", "cool", "flow"
}

EMOTIONAL_WORDS = {
    "deep", "emotion", "emotions", "emotional", "heart", "heartfelt",
    "soul", "soulful", "meaning", "meaningful", "touching",
    "tears", "feeling", "feelings", "intense", "connection",
    "memories", "memory", "nostalgia", "nostalgic",
    "remember", "remembering", "dream", "dreaming",
    "longing", "yearning", "confession", "broken", "mended"
}

NOSTALGIC_WORDS = {
    "nostalgia", "nostalgic", "memory", "memories",
    "remember", "recall", "yesterday", "childhood",
    "old", "old days", "past", "history", "back then",
    "lost time", "long ago", "retro", "classic", "faded",
    "flashback", "bittersweet", "miss", "missing"
}


# ───────────────────────────────
# 2. Tokenization + simple stemming
# ───────────────────────────────

def _tokenize(text: str):
    text = text.lower()
    return re.findall(r"[a-z']+", text)


def _normalize(word: str) -> str:
    if word.endswith("ing") and len(word) > 4:
        return word[:-3]
    if word.endswith("ed") and len(word) > 3:
        return word[:-2]
    if word.endswith("s") and len(word) > 3:
        return word[:-1]
    return word


# ───────────────────────────────
# 3. Heuristic (non-ML) mood scoring
# ───────────────────────────────

def _heuristic_scores(text: str):
    tokens = [_normalize(w) for w in _tokenize(text)]
    total_words = len(tokens) or 1
    counts = Counter(tokens)

    def score(wordset):
        return sum(counts[_normalize(w)] for w in wordset) / total_words

    scores = {
        "happy": score(HAPPY_WORDS),
        "sad": score(SAD_WORDS),
        "energetic": score(ENERGETIC_WORDS),
        "calm": score(CALM_WORDS),
        "emotional": score(EMOTIONAL_WORDS),
        "nostalgic": score(NOSTALGIC_WORDS),
    }

    mood = max(scores, key=scores.get)
    max_score = scores[mood]
    if max_score < 0.01:
        mood = "mixed"

    return mood, scores, total_words


# ───────────────────────────────
# 4. ML model (TF-IDF + Logistic Regression)
# ───────────────────────────────

_vectorizer: TfidfVectorizer | None = None
_classifier: LogisticRegression | None = None
_model_trained: bool = False


def _infer_label_from_filename(filename: str) -> str | None:
    """
    Infer mood label from file name keywords.
    E.g. 'Jazzy Happy.txt' -> 'happy', 'rock sad.txt' -> 'sad'
    """
    name = filename.lower()

    keyword_map = {
        "happy": "happy",
        "sad": "sad",
        "energetic": "energetic",
        "energy": "energetic",
        "emotional": "emotional",
        "emotion": "emotional",
        "nostalgic": "nostalgic",
        "nostalgia": "nostalgic",
        "calm": "calm",
        "chill": "calm",
        "relax": "calm",
    }

    for key, label in keyword_map.items():
        if key in name:
            return label

    # if nothing matches, return None (unlabeled)
    return None


def _train_ml_model():
    """
    Train TF-IDF + Logistic Regression on lyrics in Backend/lyrics.
    Labels are inferred from filename keywords.
    """
    global _vectorizer, _classifier, _model_trained

    lyrics_dir = os.path.join(os.path.dirname(__file__), "lyrics")
    texts = []
    labels = []

    for filepath in glob.glob(os.path.join(lyrics_dir, "*.txt")):
        fname = os.path.basename(filepath)
        label = _infer_label_from_filename(fname)
        if label is None:
            continue  # skip unlabeled files

        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception:
            continue

        if not text.strip():
            continue

        texts.append(text)
        labels.append(label)

    if len(texts) < 3:
        # not enough data to train – keep _model_trained = False
        print("[model_logic] Not enough labeled lyrics to train ML model; using heuristic only.")
        return

    _vectorizer = TfidfVectorizer(
        lowercase=True,
        stop_words="english",
        ngram_range=(1, 2),
        max_features=5000,
    )
    X = _vectorizer.fit_transform(texts)

    _classifier = LogisticRegression(max_iter=200, multi_class="auto")
    _classifier.fit(X, labels)

    _model_trained = True
    print(f"[model_logic] ML model trained on {len(texts)} labeled songs.")


# Train model on module import
try:
    _train_ml_model()
except Exception as e:
    print("[model_logic] Error training ML model, will use heuristic only:", e)
    _model_trained = False


def _ml_predict(text: str):
    """
    Predict mood using trained ML model.
    Returns (mood, scores_dict, total_words).
    Raises RuntimeError if model not trained.
    """
    if not _model_trained or _vectorizer is None or _classifier is None:
        raise RuntimeError("ML model not trained")

    tokens = _tokenize(text)
    total_words = len(tokens) or 1

    X = _vectorizer.transform([text])
    proba = _classifier.predict_proba(X)[0]
    classes = _classifier.classes_

    scores = {label: 0.0 for label in MOOD_LABELS}
    for cls, p in zip(classes, proba):
        scores[cls] = float(p)

    mood = classes[int(np.argmax(proba))]

    if proba.max() < 0.35:  # very unsure
        mood = "mixed"

    return mood, scores, total_words


# ───────────────────────────────
# 5. Public API used by Flask
# ───────────────────────────────

def analyze_text_mood(text: str):
    """
    This is what Flask uses for single-text analysis.
    - Try ML model first
    - If ML not available, use heuristic keyword scores
    """
    text = text or ""
    try:
        mood, scores, total_words = _ml_predict(text)
    except Exception:
        mood, scores, total_words = _heuristic_scores(text)

    return {
        "mood": mood,
        "scores": scores,
        "total_words": total_words,
    }

# model_logic.py (add these helpers near top of file)

import json
import os

# Where to store manual overrides:
OVERRIDES_PATH = os.path.join(os.path.dirname(__file__), "mood_overrides.json")

def load_overrides():
    """Load optional overrides mapping filename -> mood (uppercase)."""
    try:
        if os.path.exists(OVERRIDES_PATH):
            with open(OVERRIDES_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            # ensure uppercase moods
            return {k: v.upper() for k, v in data.items()}
    except Exception:
        pass
    return {}

def decide_mood_from_scores(scores: dict, min_confidence: float = 0.30):
    """
    Given scores (lowercase keys), return a mood label or 'MIXED'/'UNKNOWN'.
     - If top score >= min_confidence -> return that mood uppercase
     - If multiple near-tied scores or top < min_confidence -> return 'MIXED' (or 'UNKNOWN')
    """
    if not scores:
        return "UNKNOWN"

    # Ensure floats and remove any non-numeric values
    clean = {}
    for k, v in scores.items():
        try:
            clean[k] = float(v)
        except Exception:
            clean[k] = 0.0

    # find top and second
    sorted_items = sorted(clean.items(), key=lambda x: x[1], reverse=True)
    top_key, top_score = sorted_items[0]
    second_score = sorted_items[1][1] if len(sorted_items) > 1 else 0.0

    # Heuristic:
    # - if top_score < min_confidence -> MIXED (not confident)
    # - if top_score - second_score < 0.10 -> MIXED (too close to call)
    # - else return top_key
    if top_score < min_confidence:
        return "MIXED"
    if (top_score - second_score) < 0.10:
        return "MIXED"

    return top_key.upper()

# Example usage inside run_lyrics_pipeline:
def run_lyrics_pipeline(min_confidence: float = 0.30):
    """
    Walks lyrics/ folder, runs detect_mood_for_text per file, and returns file entries.
    Each file entry will have 'mood' set using decide_mood_from_scores(), with overrides applied.
    """
    backend_dir = os.path.dirname(__file__)
    lyrics_dir = os.path.join(backend_dir, "lyrics")
    overrides = load_overrides()

    files = []
    for fname in sorted(os.listdir(lyrics_dir)):
        if not fname.lower().endswith(".txt"):
            continue
        path = os.path.join(lyrics_dir, fname)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                txt = f.read()
        except Exception:
            txt = ""

        # call your detection function (must exist)
        analysis = detect_mood_for_text(txt)
        scores = analysis.get("scores", {}) or {}

        # manual override check:
        if fname in overrides:
            mood = overrides[fname]
            source = "override"
        else:
            mood = decide_mood_from_scores(scores, min_confidence=min_confidence)
            source = analysis.get("used_fallback_model", "model")

        preview = txt.strip().replace("\n", " ")[:300]

        files.append({
            "filename": fname,
            "path": path,
            "mood": mood,
            "scores": scores,
            "preview": preview,
            "length_words": len(txt.split()),
            "source": source,
        })

    # return summary + files
    counts = {}
    for f in files:
        counts[f["mood"]] = counts.get(f["mood"], 0) + 1

    return {
        "files": files,
        "counts": counts,
        "total_files": len(files)
    }

def run_lyrics_pipeline():
    """
    Analyze all .txt files in Backend/lyrics.
    Uses analyze_text_mood() so it benefits from ML too.
    """
    lyrics_dir = os.path.join(os.path.dirname(__file__), "lyrics")

    files_data = []
    total_docs = 0

    for filepath in glob.glob(os.path.join(lyrics_dir, "*.txt")):
        total_docs += 1
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception:
            continue

        analysis = analyze_text_mood(text)

        files_data.append({
            "filename": os.path.basename(filepath),
            "mood": analysis["mood"],
            "scores": analysis["scores"],
            "length": analysis["total_words"],
            "preview": text[:180],
        })

    mood_counts = Counter(f["mood"] for f in files_data)

    summary = {
        "num_files": total_docs,
        "mood_distribution": mood_counts,
    }

    return {
        "files": files_data,
        "summary": summary,
    }


def detect_mood_for_text(text: str) -> dict:
    """
    Return: {
      "mood": "HAPPY" | "SAD" | "MIXED" | ...,
      "scores": { "happy":0.12, "sad":0.05, ... },
      "word_count": n,
      "used_fallback_model": "keyword" or "ml"
    }
    Behavior:
      - If short input (<= SHORT_WORDS_THRESH) -> run keyword detector first.
      - Otherwise run ML detector (existing logic) and if top_score < CONFIDENCE_THRESH -> fallback to keyword model.
      - Always return which method was used.
    """
    SHORT_WORDS_THRESH = 5        # <= this -> use keyword model immediately
    CONFIDENCE_THRESH = 0.20      # top score must be >= this to trust ML

    text = (text or "").strip()
    words = text.split()
    word_count = len(words)

    # 1) If very short, use the keyword model right away (high precision)
    if word_count <= SHORT_WORDS_THRESH:
        kw_result = kw_detect_mood(text)
        # kw_detect_mood should return dict: { "mood": "...", "scores": {...} }
        mood = kw_result.get("mood", "MIXED")
        return {
            "mood": mood,
            "scores": kw_result.get("scores", {}),
            "word_count": word_count,
            "used_fallback_model": "keyword"
        }

    # 2) Otherwise run your existing ML-based pipeline.
    #    I assume you have a function run_model_on_text(text) -> {'scores': {...}}
    #    Replace the call below with your actual ML inference call.
    try:
        ml_output = run_model_on_text(text)   # <-- use your existing ML inference
        scores = ml_output.get("scores", {})  # dictionary of mood -> float (0..1)
    except Exception as e:
        # model failed — fallback to keyword
        kw_result = kw_detect_mood(text)
        return {
            "mood": kw_result.get("mood", "MIXED"),
            "scores": kw_result.get("scores", {}),
            "word_count": word_count,
            "used_fallback_model": "keyword",
            "error": str(e)
        }

    # Find top mood and its score
    if not scores:
        # nothing from ML -> fallback
        kw_result = kw_detect_mood(text)
        return {
            "mood": kw_result.get("mood", "MIXED"),
            "scores": kw_result.get("scores", {}),
            "word_count": word_count,
            "used_fallback_model": "keyword"
        }

    # Determine dominant mood and if it's confident
    dominant_mood = max(scores, key=scores.get)
    top_score = float(scores[dominant_mood])

    if top_score < CONFIDENCE_THRESH:
        # fallback to keyword model for higher precision
        kw_result = kw_detect_mood(text)
        # if keyword model returns something confident (non-MIXED) we prefer it
        return {
            "mood": kw_result.get("mood", dominant_mood),
            "scores": kw_result.get("scores", scores),
            "word_count": word_count,
            "used_fallback_model": "keyword_if_confident_else_ml"
        }

    # Otherwise trust ML
    return {
        "mood": dominant_mood,
        "scores": scores,
        "word_count": word_count,
        "used_fallback_model": "ml"
    }

