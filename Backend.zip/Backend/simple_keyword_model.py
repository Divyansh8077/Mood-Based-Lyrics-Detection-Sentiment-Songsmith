# simple_keyword_model.py
import re
from typing import Dict

def _clean_text(text: str) -> str:
    return re.sub(r"[^a-zA-Z\s]", "", (text or "").lower())

# Conservative, high-precision keywords
MOODS = {
    "HAPPY": ["happy","joy","smile","laugh","sun","bright","cheer","delight","glad","glee"],
    "SAD": ["sad","cry","tears","crying","pain","hurt","alone","broken","lost","empty"],
    "ENERGETIC": ["energetic","energy","power","run","fast","rush","alive","fire","strong","dance"],
    "CALM": ["calm","peace","quiet","soft","slow","gentle","rest","breathe","still","ocean"],
    "NOSTALGIC": ["remember","memory","yesterday","past","miss","old","before","forever","gone","moments"],
    "EMOTIONAL": ["heart","feel","soul","deep","touch","love","feelings","teardrop","emotion","inside"],
}

def kw_detect_mood(text: str) -> Dict:
    """
    High-precision keyword mood detector.
    Returns { "mood": "HAPPY"/"SAD"/.../"MIXED"/"UNKNOWN", "scores": {mood:score} }
    Scores are small integers normalized to sum 1 when sum>0.
    """
    txt = _clean_text(text)
    tokens = txt.split()
    counts = {}
    for mood, keywords in MOODS.items():
        cnt = 0
        for k in keywords:
            # count occurrences of each keyword token
            cnt += tokens.count(k)
        counts[mood] = cnt

    total = sum(counts.values())
    if total == 0:
        # no strong keywords found
        return {"mood": "UNKNOWN", "scores": {m.lower(): 0.0 for m in MOODS.keys()}}

    # normalized scores
    scores = {m.lower(): (counts[m] / total) for m in counts}
    top_mood = max(scores, key=scores.get)
    return {"mood": top_mood.upper(), "scores": scores}
