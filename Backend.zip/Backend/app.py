
from flask import Flask, jsonify, request
from flask_cors import CORS

from model_logic import run_lyrics_pipeline, detect_mood_for_text

app = Flask(__name__)
CORS(app)  # allow React from localhost:3000 / 3001


@app.route("/", methods=["GET"])
def home():
    return "<h3>Flask backend is running. Use /run-model, /detect-mood, /recommend, /recommend-from-text</h3>"


@app.route("/run-model", methods=["GET"])
def run_model():
    """
    Returns analysis of all .txt files in Backend/lyrics.
    Used by Dashboard & Analyze pages.
    """
    try:
        result = run_lyrics_pipeline()
        return jsonify({"status": "ok", "result": result})
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        return jsonify({"status": "error", "error": str(e), "traceback": tb}), 500


@app.route("/detect-mood", methods=["POST"])
def detect_mood():
    """
    POST body: { "text": "lyrics ..." }
    Returns mood + scores for pasted text.
    """
    data = request.get_json(force=True) or {}
    text = data.get("text", "")

    if not text.strip():
        return jsonify({"status": "error", "error": "No text provided"}), 400

    try:
        result = detect_mood_for_text(text)
        return jsonify({"status": "ok", "result": result})
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        return jsonify({"status": "error", "error": str(e), "traceback": tb}), 500


# ───────────────────────────────
#  RECOMMENDATION ENGINE HELPERS
# ───────────────────────────────
# Optional: manually fix moods for specific files
# Optional: manually fix moods for specific files
FILE_MOOD_OVERRIDES = {
    "motivation_song.txt": "happy",
    # you can add more if needed
}

# Map mood -> required keyword(s) in filename
MOOD_FILENAME_TAGS = {
    "happy": ["happy"],
    "sad": ["sad"],
    "energetic": ["energetic"],
    "nostalgic": ["nostalgic"],
    "emotional": ["emotional", "love"],  # e.g. love_song.txt
    "calm": ["calm"],
}

def _compute_recommendations(target_mood: str, top_n: int = 5):
    target_mood = (target_mood or "").lower().strip()

    pipeline = run_lyrics_pipeline()
    files = pipeline.get("files", [])

    scored_files = []
    for f in files:
        filename = f.get("filename") or ""

        scores = (f.get("scores") or {})
        scores_lower = {k.lower(): float(v) for k, v in scores.items()}
        if not scores_lower:
            continue

        # 1) dominant mood from scores
        dominant_mood = max(scores_lower, key=scores_lower.get)
        dominant_score = scores_lower[dominant_mood]

        # 2) manual override if we forced a mood
        override = FILE_MOOD_OVERRIDES.get(filename)
        if override:
            dominant_mood = override.lower()

        # 3) filename-based filter: require filename to carry a tag for that mood
        tags = MOOD_FILENAME_TAGS.get(target_mood, [])
        name_l = filename.lower()
        if tags and not any(tag in name_l for tag in tags):
            # e.g. mood = "sad" but filename doesn't contain "sad"
            continue

        # 4) STRICT FILTER: final mood must match requested mood
        if dominant_mood != target_mood:
            continue

        # 5) minimum strength threshold
        if dominant_score <= 0.15:  # 15% or less = too weak
            continue

        scored_files.append(
            {
                "filename": filename,
                "mood": dominant_mood,
                "score": dominant_score,
                "preview": f.get("preview", ""),
            }
        )

    scored_files.sort(key=lambda x: x["score"], reverse=True)
    recommendations = scored_files[:top_n]

    summary = {
        "target_mood": target_mood,
        "total_files": len(files),
        "matched_files": len(recommendations),
    }

    return recommendations, summary





# ───────────────────────────────
#  RECOMMENDATION ENDPOINTS
# ───────────────────────────────

@app.route("/recommend", methods=["GET"])
def recommend():
    """
    GET /recommend?mood=happy&top=5

    Returns recommended songs for a given mood label.
    """
    mood = request.args.get("mood", "").lower().strip()
    top_n = int(request.args.get("top", 5) or 5)

    if not mood:
        return jsonify({"status": "error", "error": "Missing 'mood' query param"}), 400

    try:
        recs, summary = _compute_recommendations(mood, top_n=top_n)
        return jsonify({
            "status": "ok",
            "query_mood": mood,
            "recommendations": recs,
            "summary": summary
        })
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        return jsonify({"status": "error", "error": str(e), "traceback": tb}), 500


@app.route("/recommend-from-text", methods=["POST"])
def recommend_from_text():
    """
    POST body: { "text": "lyrics ...", "top": 5? }

    1) Detects mood from the text
    2) Recommends songs for that mood
    """
    data = request.get_json(force=True) or {}
    text = data.get("text", "")
    top_n = int(data.get("top", 5) or 5)

    if not text.strip():
        return jsonify({"status": "error", "error": "No text provided"}), 400

    try:
        analysis = detect_mood_for_text(text)
        mood = analysis.get("mood", "mixed")
        recs, summary = _compute_recommendations(mood, top_n=top_n)

        return jsonify({
            "status": "ok",
            "detected_mood": mood,
            "analysis": analysis,
            "recommendations": recs,
            "summary": summary,
        })
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        return jsonify({"status": "error", "error": str(e), "traceback": tb}), 500


if __name__ == "__main__":
    app.run(port=5000, debug=True)
