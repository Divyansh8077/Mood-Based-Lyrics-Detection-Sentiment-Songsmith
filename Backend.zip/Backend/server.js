// server.js (updated to call Windows Python 'py -3')
const express = require("express");
const cors = require("cors");
const { execFile } = require("child_process");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.post("/run-notebook", (req, res) => {
  const nbPath = req.body.path;
  if (!nbPath) return res.status(400).json({ error: "path required in body" });

  const fullPath = path.resolve(nbPath);

  // Use 'py -3' launcher so the same Windows Python (with pip) is used.
  execFile("py", ["-3", path.join(__dirname, "run_notebook.py"), fullPath], { maxBuffer: 1024 * 1024 * 50 }, (error, stdout, stderr) => {
    if (error) {
      console.error("exec error:", error);
      try {
        const out = JSON.parse(stdout || "{}");
        return res.status(500).json({ error: error.message, result: out, stderr });
      } catch (e) {
        return res.status(500).json({ error: error.message, stderr, stdout });
      }
    }
    try {
      const out = JSON.parse(stdout || "{}");
      return res.json(out);
    } catch (e) {
      return res.status(500).json({ error: "Invalid JSON from runner", stdout, stderr });
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
